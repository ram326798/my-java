
import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Map;
import java.util.TreeMap;

public class Main {
	public static void main(String[] args) throws NumberFormatException, IOException, ParseException{
		BufferedReader br=new BufferedReader(new InputStreamReader(System.in));
		SimpleDateFormat sdf=new SimpleDateFormat("dd-MM-yyyy");
		Map<Date,Integer>map=new TreeMap<Date,Integer>();
		List<Note>noteList=new ArrayList<>();
		System.out.println("Enter the number of notes:");
		//Your code here
		int n=Integer.parseInt(br.readLine());
		for(int i=0;i<n;i++)
		{
			String notes=br.readLine();
			String no[]=notes.split(",");
			Note note=new Note();
			note=new Note(no[0],no[1],Double.parseDouble(no[2]),Double.parseDouble(no[3]),sdf.parse(no[4]));
			noteList.add(note);
		}
		
		Map<Date,Integer>m=Note.calculateDateCount(noteList);
		System.out.format("%-15s %s\n","Date","Count");
		for(Date d:m.keySet())
		{
			System.out.format("%-15s %s\n",sdf.format(d),m.get(d));
		}
		
		
	}
}