import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;
import java.util.Map;
import java.util.TreeMap;

public class Note{
	//Your code here
	private String name;
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getContent() {
		return content;
	}
	public void setContent(String content) {
		this.content = content;
	}
	public Double getSize() {
		return size;
	}
	public void setSize(Double size) {
		this.size = size;
	}
	public Double getPriorityLevel() {
		return priorityLevel;
	}
	public void setPriorityLevel(Double priorityLevel) {
		this.priorityLevel = priorityLevel;
	}
	public Date getCreatedDate() {
		return createdDate;
	}
	public void setCreatedDate(Date createdDate) {
		this.createdDate = createdDate;
	}
	private String content;
	private Double size;
	private Double priorityLevel;
	private Date createdDate;
	public Note(String name, String content, Double size, Double priorityLevel, Date createdDate) {
		super();
		this.name = name;
		this.content = content;
		this.size = size;
		this.priorityLevel = priorityLevel;
		this.createdDate = createdDate;
	}
	public Note() {
		super();
		// TODO Auto-generated constructor stub
	}
	
	public static Map<Date,Integer> calculateDateCount(List<Note> list){
		//Your code here
		Map<Date,Integer>map=new TreeMap<Date,Integer>();
		SimpleDateFormat sdf=new SimpleDateFormat("dd-MM-yyyy");
		for(Note n:list)
		{
			if(map.containsKey(n.getCreatedDate()))
			{
				map.put(n.getCreatedDate(),map.get(n.getCreatedDate())+1);
			}
			else
			{
				map.put(n.getCreatedDate(),1);
			}
		}
		return map;
	}
}
