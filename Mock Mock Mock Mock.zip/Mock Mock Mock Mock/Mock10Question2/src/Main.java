import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.text.ParseException;
import java.util.ArrayList;

public class Main {
	public static void main(String args[]) throws IOException, NumberFormatException, ParseException {
		BufferedReader br=new BufferedReader(new InputStreamReader(System.in));
		System.out.println("Enter the name of the book:");
		String name=br.readLine();
		Notebook nb=new Notebook(name,new ArrayList<Note>());
		System.out.println("1.Add Note\n2.Delete Note\n3.Display Notes\n4.Exit\nEnter your choice:");
		int choice=Integer.parseInt(br.readLine());
		while(choice>0 && choice<4)
		{
			if(choice==1)
			{
				 System.out.println("Enter the details of note in CSV format:");
			        String detail=br.readLine();
			        Note n=Note.createNote(detail);
			        nb.addNoteToBook(n);
			        System.out.println("Note successfully added");
			}
		
			else if(choice==2)
			{
				System.out.println("Enter the name of the note to be deleted:");
		        String nm=br.readLine();
		        boolean b=nb.removeNoteFromBook(nm);
		        if(b)
		        	System.out.println("Note successfully deleted");
		        else
		        	System.out.println("Note not found in the Book");
			}
			else
			{
				nb.displayNotes();
			}
			System.out.println("1.Add Note\n2.Delete Note\n3.Display Notes\n4.Exit\nEnter your choice:");
			choice=Integer.parseInt(br.readLine());
		
		}
		

	}
}

