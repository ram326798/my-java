import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;

public class Note {
	
	private String name;
	private String content;
	private Double size;
	private Date createdDate;
	private Double priorityLevel;
	
	public Note() {
		super();
		// TODO Auto-generated constructor stub
	}

	public Note(String name, String content, Double size, Date createdDate, Double priorityLevel) {
		super();
		this.name = name;
		this.content = content;
		this.size = size;
		this.createdDate = createdDate;
		this.priorityLevel = priorityLevel;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getContent() {
		return content;
	}

	public void setContent(String content) {
		this.content = content;
	}

	public Double getSize() {
		return size;
	}

	public void setSize(Double size) {
		this.size = size;
	}

	public Date getCreatedDate() {
		return createdDate;
	}

	public void setCreatedDate(Date createdDate) {
		this.createdDate = createdDate;
	}

	public Double getPriorityLevel() {
		return priorityLevel;
	}

	public void setPriorityLevel(Double priorityLevel) {
		this.priorityLevel = priorityLevel;
	}

	public static Note createNote(String detail) throws NumberFormatException, ParseException {
		SimpleDateFormat sdf=new SimpleDateFormat("dd-MM-yyyy");
		String s[]=detail.split(",");
		Note n=new Note(s[0],s[1],Double.parseDouble(s[2]),sdf.parse(s[3]),Double.parseDouble(s[4]));
		return n;
	}
	public String toString()
	{
		SimpleDateFormat sdf=new SimpleDateFormat("dd-MM-yyyy");
		return String.format("%-15s%-25s%-10s%-15s%-10s\n", getName(),getContent(),getSize(),sdf.format(getCreatedDate()),getPriorityLevel());
		
	}
	
}
