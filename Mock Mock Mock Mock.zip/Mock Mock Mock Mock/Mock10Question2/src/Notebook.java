import java.text.SimpleDateFormat;
import java.util.List;

public class Notebook {
	private String name;
	private List<Note> noteList;
	
	Note n=new Note();
	public Notebook() {
		super();
		// TODO Auto-generated constructor stub
	}

	public Notebook(String name, List<Note> noteList) {
		super();
		this.name = name;
		this.noteList = noteList;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public List<Note> getNoteList() {
		return noteList;
	}

	public void setNoteList(List<Note> noteList) {
		this.noteList = noteList;
	}

	public void addNoteToBook(Note note) {
		noteList.add(note);
	}
	
	public Boolean removeNoteFromBook(String name) {
		for(Note n:noteList)
		{
			if(n.getName().equals(name))
			{
				noteList.remove(n);
				return true;
				
			}
		}
		return false;

	}
	
	public void displayNotes() {
		SimpleDateFormat sdf=new SimpleDateFormat("dd-MM-yyyy");
		if(noteList.isEmpty())
			System.out.println("No notes to show");
		else
		{
			System.out.println("Notes in:"+name);
			System.out.format("%-15s%-25s%-10s%-15s%-10s\n","Name","Content","Size","Created Date","Priority Level");
			for(Note n:noteList)
				System.out.print(n);
		}

	}
}
