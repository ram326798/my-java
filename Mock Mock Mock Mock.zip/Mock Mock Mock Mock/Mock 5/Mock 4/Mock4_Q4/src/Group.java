import java.util.ArrayList;
import java.util.List;

public class Group {
	
	private String name;

	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	
	
	List<Contact>contactList=new ArrayList<Contact>();
	public void addContactToGroup(Contact contact) 
	{
		contactList.add(contact);
	}
	
	public Boolean removeContactFromGroup(String name)
	{
		int flag=0;
		for(int i=0;i<contactList.size();i++)
		{
			if(name.equals(contactList.get(i).getName()))
			{
			    contactList.remove(i);
			    flag=1;
			    break;
			}
		}
		if(flag==1)
			return true;
		else
			return false;
	}
	
	public void displayContacts()
	{
		
		for(Contact c:contactList)
		{
			System.out.println(c);
		}
	}


}
