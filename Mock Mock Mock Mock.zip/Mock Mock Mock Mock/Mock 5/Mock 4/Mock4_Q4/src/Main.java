import java.io.BufferedReader;
import java.io.InputStreamReader;

public class Main {

	public static void main(String[] args) throws Exception{
		// TODO Auto-generated method stub
		BufferedReader br=new BufferedReader(new InputStreamReader(System.in));
		System.out.println("Enter the group name:");
		String group=br.readLine();
		
		Group gr=new Group();
		gr.setName(group);
		
		int choice=0;
		do
		{
			System.out.println("1.Add Contact\n2.Delete Contact\n3.Display contacts\n4.Exit\nEnter your choice:"); 
			choice=Integer.parseInt(br.readLine());
			
			switch(choice)
			{
			case 1:
				System.out.println("Enter the number of contacts");
				int num=Integer.parseInt(br.readLine());
				
				for(int i=0;i<num;i++)
				{
					String detail=br.readLine();
					Contact cont=Contact.createContact(detail);
					gr.addContactToGroup(cont);
				}
				
				break;
				
			case 2:
				System.out.println("Enter the name of the contact to be deleted:");
				String name=br.readLine();
				if(gr.removeContactFromGroup(name))
					System.out.println("Contact successfully deleted");
				else
					System.out.println("Contact not found in the group");
				break;
				
			case 3:
				System.out.println("Contacts in "+group+" group");
				gr.displayContacts();
				break;
				
			case 4:
				return;
			}
			
		}while(choice!=4);

	}

}


/*import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.text.ParseException;
import java.util.ArrayList;
public class Main {
	public static void main(String[] args) throws IOException, ParseException {
		BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
		System.out.println("Enter the group name:");
	   String gr=br.readLine();
	   Group g=new Group();
	  ArrayList<Contact>list=new ArrayList<Contact>();
	   int choice=0;
	 g.setName(gr);
	 
	    while(true)
	    {
		System.out.println("1.Add Contact\n2.Delete Contact\n3.Display contacts\n4.Exit\nEnter your choice:");
		choice=Integer.parseInt(br.readLine());
		switch(choice)
		{
		case 1:
			System.out.println("Enter the number of contact");
			int a=Integer.parseInt(br.readLine());
			for(int i=0;i<a;i++)
			{
				String inp=br.readLine();
				Contact c=Contact.createContact(inp);
				list.add(c);
			}
			break;
		case 2:
			System.out.println("Enter the name of the contact to be deleted:");
			String name=br.readLine();
			if(g.removeContactFromGroup(name,list))
			{
				System.out.println("Contact deleted");
			}
			else
				System.out.println("contact not found");
			break;
		case 3:
			g.displayContacts(list);
			break;
		case 4:
			return;
		   default:System.out.println("Invalid Choice");
			
		}
	    }
		
		
	}
}
*/

