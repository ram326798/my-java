import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Iterator;
import java.util.Map;
import java.util.Set;
import java.util.TreeMap;

public class Main {

	public static void main(String[] args) throws Exception{
		// TODO Auto-generated method stub
		BufferedReader br=new BufferedReader(new InputStreamReader(System.in));
		
		System.out.println("Enter the number of the contacts:");
		int num=Integer.parseInt(br.readLine());
		ArrayList<Contact>ar=new ArrayList<Contact>();
		Map<String,Integer> dom=new TreeMap<String,Integer>();
		
		SimpleDateFormat sdf=new SimpleDateFormat("dd-MM-yyyy");
		for(int i=0;i<num;i++)
		{
			String s[]=br.readLine().split(",");
			ar.add(new Contact(s[0],s[1],s[2],s[3],s[4],s[5],sdf.parse(s[6])));

		}
		
		dom=Contact.getContactCountForDomain(ar);
		

		System.out.format("%-15s %s\n","Domain Name","Count");
		/*for(String key:dom.keySet())
		{
			System.out.format("%-15s %s\n",key,dom.get(key));
		}
		for(Contact cont:ar)
		{
			System.out.println(cont);
		}*/
		Set<String>keys=dom.keySet();
		Iterator<String>it=keys.iterator();
		while(it.hasNext())
		{
			String key=it.next();
			int value=dom.get(key);
			System.out.format("%-15s %s\n",key,dom.get(key));
		}
	}
}