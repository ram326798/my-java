import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;
import java.util.Map;
import java.util.TreeMap;

public class Contact{
	
	private String name;
	private String company;
	private String title;
	private String mobile;
	private String alternateMobile;
	private String Email;
	private Date dateCreated;
	static SimpleDateFormat sdf=new SimpleDateFormat("dd-MM-yyyy");
	
	public Contact(String name, String company, String title, String mobile, String alternateMobile, String email,
			Date dateCreated) {
		super();
		this.name = name;
		this.company = company;
		this.title = title;
		this.mobile = mobile;
		this.alternateMobile = alternateMobile;
		this.Email = email;
		this.dateCreated = dateCreated;
	}
	
	public Contact(){}
	
	@Override
	public String toString() {
		SimpleDateFormat sdf=new SimpleDateFormat("dd-MM-yyyy");
		System.out.printf("%-15s %-15s %-20s %-15s %-20s %-15s %s",name,company,title,mobile,alternateMobile,Email,sdf.format(dateCreated));
		return "";
	}
	
	static Map<String,Integer> getContactCountForDomain(List<Contact> list)
	{
		TreeMap<String,Integer> domainCount=new TreeMap<String,Integer>();
		for(int i=0;i<list.size();i++)
		{
		Contact con=list.get(i);
		//System.out.println(con.getEmail());
		String domain=con.getEmail().substring(con.getEmail().indexOf('@')+1,con.getEmail().indexOf('.'));
		
		if(domainCount.containsKey(domain))
		{
			domainCount.put(domain, domainCount.get(domain)+1);
		}
		else
			domainCount.put(domain, 1);
		}
		return domainCount;
	}

	public String getEmail() {
		return Email;
	}

	public void setEmail(String email) {
		Email = email;
	}
	
	
}
