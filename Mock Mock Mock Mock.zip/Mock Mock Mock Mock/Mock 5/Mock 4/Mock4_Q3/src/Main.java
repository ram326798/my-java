import java.util.Scanner;

public class Main {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner sc=new Scanner(System.in);
		System.out.println("1.Email Validation\n2.Service Provider Identification\nEnter your choice:");
		Main m=new Main();
		int choice=sc.nextInt();
		if(choice==1)
		{
			String email=sc.next();
			if(m.validateEmailId(email))
			{
				System.out.println("Email is valid");
			}
			else
				System.out.println("Email is invalid");
		}
		
		if(choice==2)
		{
			String phone=sc.next();
			if(m.identifyServiceProvider(phone)==null)
				System.out.println("Mobile number is not identified");
			else
				System.out.println(m.identifyServiceProvider(phone));
		}
	}



static Boolean validateEmailId(String email)
{
	if(email.matches("[a-zA-Z]{1}[a-zA-Z0-9._]{1,}[@]{1}[a-zA-Z]{1,}[.]{1}(com|org|in|gov.in|net){1}"))
	{
		return true;
	}
	else
		return false;
}

static String identifyServiceProvider(String mobile)
{
	if(mobile.matches("(9870){1}[0-9]{6}"))
	{
		return "Airtel";
	}
	else if(mobile.matches("(7012){1}[0-9]{6}"))
		return "Jio";
	else if(mobile.matches("(8180){1}[0-9]{6}"))
		return "Vodafone";
	else
		return null;
}
}

