import java.util.Comparator;

public class DateComparator implements Comparator{
	
	public int compare(Object o1,Object o2)
	{
		Contact c1=(Contact) o1;
		Contact c2=(Contact) o2;
		return c1.getDateCreated().compareTo(c2.getDateCreated());
	}
	
	

}
