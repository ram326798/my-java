import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Collections;

public class Main {

	public static void main(String[] args) throws Exception{
		// TODO Auto-generated method stub
		BufferedReader br=new BufferedReader(new InputStreamReader(System.in));
		
		System.out.println("Enter the number of the contacts:");
		int num=Integer.parseInt(br.readLine());
		ArrayList<Contact>ar=new ArrayList<Contact>();
		SimpleDateFormat sdf=new SimpleDateFormat("dd-MM-yyyy");
		for(int i=0;i<num;i++)
		{
			String s[]=br.readLine().split(",");
			ar.add(new Contact(s[0],s[1],s[2],s[3],s[4],s[5],sdf.parse(s[6])));
		}
			
			System.out.println("1.Sort by name\n2.Sort by email domain\n3.Sort by date created"); 
			int choice=Integer.parseInt(br.readLine());
			
			switch(choice)
			{
			case 1:
				Collections.sort(ar);
				for(Contact c:ar)
				{
					System.out.println(c);
				}
				break;
			case 2:
				Collections.sort(ar,new DomainComparator());
				for(Contact c:ar)
				{
					System.out.println(c);
				}
				break;
			case 3:
				Collections.sort(ar,new DateComparator());
				for(Contact c:ar)
				{
					System.out.println(c);
				}
				break;
			case 4:
				return;
			}
			
		}

	}




/*import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.text.ParseException;
import java.util.ArrayList;
public class Main {
	public static void main(String[] args) throws IOException, ParseException {
		BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
		System.out.println("Enter the group name:");
	   String gr=br.readLine();
	   Group g=new Group();
	  ArrayList<Contact>list=new ArrayList<Contact>();
	   int choice=0;
	 g.setName(gr);
	 
	    while(true)
	    {
		System.out.println("1.Add Contact\n2.Delete Contact\n3.Display contacts\n4.Exit\nEnter your choice:");
		choice=Integer.parseInt(br.readLine());
		switch(choice)
		{
		case 1:
			System.out.println("Enter the number of contact");
			int a=Integer.parseInt(br.readLine());
			for(int i=0;i<a;i++)
			{
				String inp=br.readLine();
				Contact c=Contact.createContact(inp);
				list.add(c);
			}
			break;
		case 2:
			System.out.println("Enter the name of the contact to be deleted:");
			String name=br.readLine();
			if(g.removeContactFromGroup(name,list))
			{
				System.out.println("Contact deleted");
			}
			else
				System.out.println("contact not found");
			break;
		case 3:
			g.displayContacts(list);
			break;
		case 4:
			return;
		   default:System.out.println("Invalid Choice");
			
		}
	    }
		
		
	}
}
*/

