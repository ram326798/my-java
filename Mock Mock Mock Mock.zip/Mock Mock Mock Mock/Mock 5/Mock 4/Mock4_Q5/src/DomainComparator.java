import java.util.Comparator;

public class DomainComparator implements Comparator{
	
	public int compare(Object o1,Object o2)
	{
		Contact c1=(Contact) o1;
		Contact c2=(Contact) o2;
		String domain1=c1.getEmail();
		String domain2=c2.getEmail();
		return domain1.substring(domain1.indexOf('@'),domain1.indexOf('.')).compareTo(domain2.substring(domain2.indexOf('@'),domain2.indexOf('.')));
	}

}
