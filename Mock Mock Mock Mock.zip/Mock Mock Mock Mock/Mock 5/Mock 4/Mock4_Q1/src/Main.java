import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.text.ParseException;
import java.text.SimpleDateFormat;

public class Main {

	public static void main(String[] args) throws Exception {
		// TODO Auto-generated method stub
		
		BufferedReader br=new BufferedReader(new InputStreamReader(System.in));
		SimpleDateFormat sdf=new SimpleDateFormat("dd-MM-yyyy");
		Contact cont[]=new Contact[2];
		for(int i=0;i<2;i++)
		{
			System.out.println("Enter contact "+(i+1)+" detail:");
			String info=br.readLine();
			String s[]=info.split(",");
			cont[i]=(Contact) new Contact(s[0],s[1],s[2],s[3],s[4],s[5],sdf.parse(s[6]));
		}
		for(Contact c:cont)
		{
		
		System.out.println(c);
		}
		
		
		if(cont[0].equals(cont[1]))
		{
			System.out.println("Contact 1 is same as Contact 2");
		}
		else
		{
			System.out.println("Contact 1 and Contact 2 are different");
		}

	}

}
