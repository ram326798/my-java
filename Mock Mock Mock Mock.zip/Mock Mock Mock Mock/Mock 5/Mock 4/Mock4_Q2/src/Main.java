import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;

public class Main {

	public static void main(String[] args) throws Exception {
		// TODO Auto-generated method stub
		
		BufferedReader br=new BufferedReader(new InputStreamReader(System.in));
		SimpleDateFormat sdf=new SimpleDateFormat("dd-MM-yyyy");
		ArrayList <Contact> contactList=new ArrayList <Contact>();
		ContactBO cont=new ContactBO();
		int num=Integer.parseInt(br.readLine());
		for(int i=0;i<num;i++)
		{
			//System.out.println("Enter contact "+(i+1)+" detail:");
			String info=br.readLine();
			String s[]=info.split(",");
			contactList.add(new Contact(s[0],s[1],s[2],s[3],s[4],s[5],sdf.parse(s[6])));
		}
		System.out.println("Enter a search type:\n1.Name\n2.Date created\n3.Email domain");
		int choice=Integer.parseInt(br.readLine());
		if(choice==1)
		{
			String name[]=br.readLine().split(",");
			ArrayList <String> names=new ArrayList <String>();
			for(int i=0;i<name.length;i++)
			{
			  names.add(name[i]);
			}
			System.out.format("%-15s %-15s %-20s %-15s %-20s %-15s %s\n", "Name","Company","Title","Mobile","Alternate Mobile","Email","Date Created");
			for(Contact c:cont.findContact(contactList, names))
			{
			 System.out.println(c);
			}
		}
		
		else if(choice==2)
		{
			String date=br.readLine();
			
			System.out.format("%-15s %-15s %-20s %-15s %-20s %-15s %s\n", "Name","Company","Title","Mobile","Alternate Mobile","Email","Date Created");
			for(Contact c:cont.findContact(contactList, sdf.parse(date)))
			{
			 System.out.println(c);
			}
		}
		
		else if(choice==3)
		{
			String email=br.readLine();
			
			System.out.format("%-15s %-15s %-20s %-15s %-20s %-15s %s\n", "Name","Company","Title","Mobile","Alternate Mobile","Email","Date Created");
			for(Contact c:cont.findContact(contactList, email))
			{
			 System.out.println(c);
			}
		}
		
		else
		{
			System.out.println("Invalid Choice");
		}
		

	}

}
