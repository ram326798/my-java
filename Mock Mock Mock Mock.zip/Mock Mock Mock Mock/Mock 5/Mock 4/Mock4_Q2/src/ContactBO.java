import java.util.ArrayList;
import java.util.Date;
import java.util.List;

public class ContactBO {
	
	public List<Contact> findContact (List<Contact> contactList,List<String> name) 
	{
		
	    ArrayList <Contact> selCont=new ArrayList<Contact>();
		for(int i=0;i<contactList.size();i++)
		{
		  for(int j=0;j<name.size();j++)
		  {
		
		   if(contactList.get(i).getName().equals(name.get(j)))
				   {
			         selCont.add(contactList.get(i));
				   }
		  }
		}
		return selCont;
	}
	
	public List<Contact> findContact (List<Contact> contactList,Date dateCreated) 
	{
		
	    ArrayList <Contact> selCont=new ArrayList<Contact>();
		for(int i=0;i<contactList.size();i++)
		{
		  
		
		   if(contactList.get(i).getDateCreated().equals(dateCreated))
		   {
			  selCont.add(contactList.get(i));
		   }
		  
		}
		return selCont;
	}
	
	public List<Contact> findContact (List<Contact> contactList,String emailDomain) 
	{
		
	    ArrayList <Contact> selCont=new ArrayList<Contact>();
		for(int i=0;i<contactList.size();i++)
		{
		   String email=contactList.get(i).getEmail();
		   String domain=email.substring(email.indexOf('@')+1,email.indexOf('.'));
		   if(domain.equals(emailDomain))
				   {
			         selCont.add(contactList.get(i));
				   }
		  
		}
		return selCont;
	}
	
	

}
