import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.List;

public class Main {
	public static void main(String args[]) throws NumberFormatException, IOException, ParseException{
		BufferedReader br=new BufferedReader(new InputStreamReader(System.in));
		SimpleDateFormat sdf=new SimpleDateFormat("dd-MM-yyyy");
		List<Note> list=new ArrayList<Note>(); 
		NoteBO nb=new NoteBO();
		System.out.println("Enter the number of Notes:");
		int count=Integer.parseInt(br.readLine());
		for(int i=0;i<count;i++)
		{
			String detail=br.readLine();
			String s[]=detail.split(",");
			Note n=new Note(s[0],s[1],Double.parseDouble(s[2]),Double.parseDouble(s[3]),sdf.parse(s[4]));
			list.add(n);
		}
		System.out.println("Enter a search type:\n1.By Name\n2.By Created Date\n3.By Priority Level");
		int choice=Integer.parseInt(br.readLine());
		switch(choice)
		{
		case 1: System.out.println("Enter the Name:");
		        String name=br.readLine();
		        List<Note> l1=nb.findNote(list, name);
		        if(l1.isEmpty())
		        	System.out.println("No such note is present");
		        else
		        {
		        	  System.out.format("%-15s %-20s %-5s %-15s %s\n","Name","Content","Size","Priority Level","Created Date");
				        for(Note n:l1)
				        	System.out.format("%-15s %-20s %-5s %-15s %s\n",n.getName(),n.getContent(),n.getSize(),n.getPriorityLevel(),sdf.format(n.getCreatedDate()));
		        }
		      
		        break;
		case 2: System.out.println("Enter the Created Date:");
		        String date=br.readLine();
		        List<Note> l2=nb.findNote(list, sdf.parse(date));
		        if(l2.isEmpty())
		        	System.out.println("No such note is present");
		        else
		        {
		        	 System.out.format("%-15s %-20s %-5s %-15s %s\n","Name","Content","Size","Priority Level","Created Date");
				        for(Note n:l2)
				        	System.out.format("%-15s %-20s %-5s %-15s %s\n",n.getName(),n.getContent(),n.getSize(),n.getPriorityLevel(),sdf.format(n.getCreatedDate()));
		        }
		       
		        break;
		case 3: System.out.println("Enter the Priority Level:");
		        Double pl=Double.parseDouble(br.readLine());
		        List<Note> l3=nb.findNote(list, pl);
		        if(l3.isEmpty())
		        	System.out.println("No such note is present");
		        else
		        {
		        	 System.out.format("%-15s %-20s %-5s %-15s %s\n","Name","Content","Size","Priority Level","Created Date");
				        for(Note n:l3)
				        	System.out.format("%-15s %-20s %-5s %-15s %s\n",n.getName(),n.getContent(),n.getSize(),n.getPriorityLevel(),sdf.format(n.getCreatedDate()));
		        }
		       
		        break;
		 default:System.out.println("Invalid choice");
		         break;
		        
		}
	}
}
