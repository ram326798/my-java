import java.util.ArrayList;
import java.util.Date;
import java.util.List;

public class NoteBO {
	public List<Note> findNote(List<Note> noteList,String name){
		List<Note> l1=new ArrayList<Note>();
		for(Note n:noteList)
		{
			if(n.getName().equals(name))
				l1.add(n);
		}
		return l1;
	}
	public List<Note> findNote(List<Note> noteList,Date createdDate){
		List<Note> l2=new ArrayList<Note>();
		for(Note n:noteList)
		{
			if(n.getCreatedDate().equals(createdDate))
				l2.add(n);
		}
		return l2;
	}
	public List<Note> findNote(List<Note> noteList,Double priorityLevel){
		List<Note> l3=new ArrayList<Note>();
		for(Note n:noteList)
		{
			if(n.getPriorityLevel().equals(priorityLevel))
				l3.add(n);
		}
		return l3;
	}
}
