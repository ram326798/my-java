import java.util.Date;

public class Note {
	private String name;
	private String content;
	private Double size;
	private Double priorityLevel;
	private Date createdDate;
	public Note() {
		super();
		// TODO Auto-generated constructor stub
	}
	public Note(String name, String content, Double size, Double priorityLevel, Date createdDate) {
		super();
		this.name = name;
		this.content = content;
		this.size = size;
		this.priorityLevel = priorityLevel;
		this.createdDate = createdDate;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getContent() {
		return content;
	}
	public void setContent(String content) {
		this.content = content;
	}
	public Double getSize() {
		return size;
	}
	public void setSize(Double size) {
		this.size = size;
	}
	public Double getPriorityLevel() {
		return priorityLevel;
	}
	public void setPriorityLevel(Double priorityLevel) {
		this.priorityLevel = priorityLevel;
	}
	public Date getCreatedDate() {
		return createdDate;
	}
	public void setCreatedDate(Date createdDate) {
		this.createdDate = createdDate;
	}
	
}