import java.util.ArrayList;
import java.util.Date;
import java.util.List;
public class SongBO {
    public List<Song> findSong(List<Song> SongList,String type){
		List<Song> l1=new ArrayList<Song>();
		for(Song s:SongList)
		{
			if(s.getSongType().equals(type))
				l1.add(s);
		}
		return l1;
	}
	public List<Song> findSong(List<Song> SongList,Date dateDownloaded){
		List<Song> l2=new ArrayList<Song>();
		for(Song s:SongList)
		{
			if(s.getDateDownloaded().equals(dateDownloaded))
				l2.add(s);
		}
		return l2;
	}
	public List<Song> findSong(List<Song> SongList,Double rating){
		List<Song> l3=new ArrayList<Song>();
		for(Song s:SongList)
		{
			if(s.getRating().equals(rating))
				l3.add(s);
		}
		return l3;
	}
}
