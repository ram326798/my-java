import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
public class Main {
    public static void main(String[] args) throws NumberFormatException, IOException, ParseException {
		BufferedReader br=new BufferedReader(new InputStreamReader(System.in));
		SongBO sb = new SongBO();
		SimpleDateFormat sdf=new SimpleDateFormat("dd-MM-yyyy");
		List<Song> list=new ArrayList<Song>();
		System.out.println("Enter the number of Songs:");
		int n = Integer.parseInt(br.readLine());
		for(int i=0;i<n;i++)
		{
			String detail=br.readLine();
			Song so=Song.createSong(detail);
			list.add(so);
		}
		System.out.println("Enter a search type:\n1.Song Type\n2.Date of Download\n3.Rating");
		int choice=Integer.parseInt(br.readLine());
		
		switch(choice)
		{
		case 1: System.out.println("Enter the song type:");
		        String type=br.readLine();
		        List<Song> l1=sb.findSong(list, type);
		        System.out.format("%-15s %-15s %-20s %-15s %-20s %-15s\n","Name","Artist","Song Type","Rating","No of Download","Date of Download");
		        for(Song s1:l1)
		        	System.out.format("%-15s %-15s %-20s %-15s %-20s %-15s\n", s1.getName(),s1.getArtist(),s1.getSongType(),s1.getRating(),s1.getNumberOfDownloads(),sdf.format(s1.getDateDownloaded()));
		        break;
		case 2: System.out.println("Enter the date:");
		        String date=br.readLine();
		        List<Song> l2=sb.findSong(list,sdf.parse(date));
		        System.out.format("%-15s %-15s %-20s %-15s %-20s %-15s\n","Name","Artist","Song Type","Rating","No of Download","Date of Download");
		        for(Song s1:l2)
		        System.out.format("%-15s %-15s %-20s %-15s %-20s %-15s\n", s1.getName(),s1.getArtist(),s1.getSongType(),s1.getRating(),s1.getNumberOfDownloads(),sdf.format(s1.getDateDownloaded()));
		        break;
		case 3: System.out.println("Enter the rating:");
		        Double rating=Double.parseDouble(br.readLine());
		        List<Song> l3=sb.findSong(list,rating);
		        System.out.format("%-15s %-15s %-20s %-15s %-20s %-15s\n","Name","Artist","Song Type","Rating","No of Download","Date of Download");
		        for(Song s1:l3)
		        	System.out.format("%-15s %-15s %-20s %-15s %-20s %-15s\n", s1.getName(),s1.getArtist(),s1.getSongType(),s1.getRating(),s1.getNumberOfDownloads(),sdf.format(s1.getDateDownloaded()));
		        break;
		default: System.out.println("Invalid choice");
		        break;
		
		}
		
	}
}
