import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;

public class Song {
	private String name;
	private String artist;
	private String songType;
	private Double rating;
	private Integer numberOfDownloads;
	private Date dateDownloaded;
	
	
	public Song() {
		super();
		// TODO Auto-generated constructor stub
	}


	public String getName() {
		return name;
	}


	public void setName(String name) {
		this.name = name;
	}


	public String getArtist() {
		return artist;
	}


	public void setArtist(String artist) {
		this.artist = artist;
	}


	public String getSongType() {
		return songType;
	}


	public void setSongType(String songType) {
		this.songType = songType;
	}


	public Double getRating() {
		return rating;
	}


	public void setRating(Double rating) {
		this.rating = rating;
	}


	public Integer getNumberOfDownloads() {
		return numberOfDownloads;
	}


	public void setNumberOfDownloads(Integer numberOfDownloads) {
		this.numberOfDownloads = numberOfDownloads;
	}


	public Date getDateDownloaded() {
		return dateDownloaded;
	}


	public void setDateDownloaded(Date dateDownloaded) {
		this.dateDownloaded = dateDownloaded;
	}


	public Song(String name, String artist, String songType, Double rating, Integer numberOfDownloads,
			Date dateDownloaded) {
		super();
		this.name = name;
		this.artist = artist;
		this.songType = songType;
		this.rating = rating;
		this.numberOfDownloads = numberOfDownloads;
		this.dateDownloaded = dateDownloaded;
	}


	public static Song createSong(String song) throws NumberFormatException, ParseException{
		SimpleDateFormat sdf=new SimpleDateFormat("dd-MM-yyyy");
		String s[]=song.split(",");
		Song so=new Song(s[0],s[1],s[2],Double.parseDouble(s[3]),Integer.parseInt(s[4]),sdf.parse(s[5]));
		return so;
	}
	
}
